export interface Coordinates {
    latitude: number;
    longitude: number;
}

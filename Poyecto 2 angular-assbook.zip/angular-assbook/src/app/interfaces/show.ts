export enum Show {
  image = 1,
  location = 2
}

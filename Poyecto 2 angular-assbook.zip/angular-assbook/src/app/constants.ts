// data SERVER

//export const SERVER ="https://api.fullstackpro.es/assbook-lite"
export const SERVER = "https://api.fullstackpro.es/assbook";
//export const SERVER = "https://github.com/arturober/assbook-services"
//"Bing maps API key";
export const BINGMAP_API_KEY ="AmCsCCqcPEgBpcQEt-j_fZpvSQ_GhKqyvzOk1UiIb3vd1l1Usz51mj-K1uB9hvxl";
export const GOOGLE_PROYECT_ID = "746820501392-oalflicqch2kuc12s8rclb5rf7b1fist.apps.googleusercontent.com"

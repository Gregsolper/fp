// data SERVER

export const SERVER ="https://api.fullstackpro.es/assbook-lite"
//export const SERVER = "https://api.fullstackpro.es/assbook";
//"Bing maps API key";
export const API_KEY ="AmCsCCqcPEgBpcQEt-j_fZpvSQ_GhKqyvzOk1UiIb3vd1l1Usz51mj-K1uB9hvxl";
